import{dT as t}from"./card-a8575c83.js";function s(s){const n=t(s);return n.setMinutes(59,59,999),n}function n(s){const n=t(s);return n.setMinutes(0,0,0),n}export{s as e,n as s};
